anoNascimento = int(input("Ano de nascimento: "))
idadeFutura = 2025 - anoNascimento

print(idadeFutura)