salarioMensal = float(input("Insira seu salário: "))
salarioMinimo = 1300
quantiadeSalariosMinimos = salarioMensal /1300
print("Você recebe: ", quantiadeSalariosMinimos, "salários mínimos.")