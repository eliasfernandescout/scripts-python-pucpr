distancia = float(input("Digite a distância total percorrida (em KM): "))
combustivel = float(input("Digite o volume de combustível consumido (em litros): "))

consumo_medio = distancia / combustivel

print("O consumo médio do automóvel é de", consumo_medio, "km/l")
