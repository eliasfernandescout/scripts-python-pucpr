numero = int(input("Digite um número inteiro: "))

antecessor = numero - 1
sucessor = numero + 1

print("O antecessor de", numero, "é", antecessor)
print("O sucessor de", numero, "é", sucessor)
